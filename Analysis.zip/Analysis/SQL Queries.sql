USE pizza_analysis;
SELECT * FROM pizza_analysis.mastertablep;

-- BASIC
-- Total no. of orders placed
SELECT COUNT(order_details_id) AS 'Total_no_of_order'
FROM mastertablep;

-- total revenue generated
SELECT ROUND(SUM(price * quantity), 2) AS 'Total_Revenue'
FROM mastertablep;

-- identify the highest priced pizza 
SELECT name, price
FROM mastertablep
ORDER BY price DESC
LIMIT 1;

-- the most common pizza size ordered
SELECT size, COUNT(*) AS order_count
FROM mastertablep
GROUP BY size
ORDER BY order_count DESC
LIMIT 1;

-- Top 5 most ordered pizza types along with their quantities
SELECT pizza_type_id, SUM(quantity) AS total_quantity
FROM mastertablep
GROUP BY pizza_type_id
ORDER BY total_quantity DESC
LIMIT 5;

-- INTERMEDIATE
                /*All the 4 tables are already joined into one mastertablep before importing*/
-- the total quantity of each pizza category ordered.
SELECT category, SUM(quantity) AS total_quantity
FROM mastertablep
GROUP BY category;

-- distribution of orders by hour of the day.
SELECT HOUR(time) AS 'order_hour', COUNT(*) AS 'order_count'
FROM mastertablep 
GROUP BY HOUR(time)
ORDER BY order_hour;

-- the category-wise distribution of pizzas.
SELECT category, COUNT(*) AS order_count
FROM mastertablep
GROUP BY category;

-- the average number of pizzas ordered per day
SELECT distinct(date) AS order_date, AVG(quantity) AS avg_quantity
FROM  mastertablep
GROUP BY order_date;

-- top 3 most ordered pizza types based on revenue.
SELECT pizza_type_id, SUM(quantity * price) AS total_revenue
FROM mastertablep
GROUP BY pizza_type_id
ORDER BY total_revenue DESC
LIMIT 3;

-- ADVANCED
-- percentage contribution of each pizza type to total revenue
SELECT 
    pizza_type_id,
    CONCAT(ROUND((SUM(quantity * price) / (SELECT 
                            SUM(quantity * price)
                        FROM mastertablep) * 100),
                    2),
            '%') AS 'percentage_contribution'
FROM mastertablep
GROUP BY pizza_type_id;

-- cumulative revenue generated over time.
SELECT date, 
       ROUND(SUM(quantity * price) OVER (ORDER BY date),
       2) AS 'cumulative_revenue'
FROM mastertablep
ORDER BY date;

-- top 3 most ordered pizza types based on revenue for each pizza category
WITH revenue_per_pizza AS (
    SELECT category, pizza_type_id , SUM(quantity * price) AS 'total_revenue'
    FROM mastertablep
    GROUP BY category, pizza_type_id
)
SELECT category, pizza_type_id, total_revenue
FROM (
    SELECT category, pizza_type_id, total_revenue,
           ROW_NUMBER() OVER (PARTITION BY category ORDER BY total_revenue DESC) AS 'p_rank'
    FROM revenue_per_pizza
) ranked_pizzas
WHERE p_rank <= 3;

